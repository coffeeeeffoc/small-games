import {
  RANKED_RULE_VERSION,
  createNightReplay,
  applyNightReplay,
  nightReplayResult,
} from '../../../games/local/night-overwatch/assets/scripts/core/Replay.ts';
import {
  MISSIONS,
  CAMPAIGN_BOARD_VERSION,
} from '../../../games/local/night-overwatch/assets/scripts/core/MissionCatalog.ts';
import { PROGRESSION } from '../../../games/local/night-overwatch/assets/scripts/core/Progression.ts';
import { Simulation } from '../../../games/local/night-overwatch/assets/scripts/core/Simulation.ts';

export default {
  id: 'night-overwatch',
  title: '夜航守望',
  version: RANKED_RULE_VERSION,
  boardVersion: 'night-records-v1',
  progression: PROGRESSION,
  boardKey: (board) =>
    `night-overwatch:${board}:${board.startsWith('level-') ? CAMPAIGN_BOARD_VERSION : 'night-records-v1'}`,
  configure(state, loadout) {
    const sim = Simulation.restore(state.simulation);
    sim.applyLoadout(loadout);
    return { ...state, simulation: sim.checkpoint() };
  },
  boards: [
    ...['clears', 'points', 'win-rate'].map((id, i) => ({
      id,
      title: ['通关榜', '积分榜', '胜率榜'][i],
      guestAllowed: true,
      scoreUnit: ['关', '分', '比率'][i],
      secondaryUnit: 'milliseconds',
      description: [
        '最高通过关卡序号',
        '经服务端结算的累计积分',
        '真人开局胜场/场次',
      ][i],
    })),
    ...MISSIONS.map((mission) => ({
      id: `level-${mission.id}`,
      title: mission.name[0],
      guestAllowed: true,
      scoreUnit: '次',
      secondaryUnit: 'milliseconds',
      description: '本关经服务端验证的最快通关用时；辅助、试玩和失败不计入。',
    })),
  ],
  create(board, _seed, levelId) {
    if (
      board !== `level-${levelId}` ||
      !MISSIONS.some((mission) => mission.id === levelId)
    )
      throw Error('Invalid level');
    return createNightReplay('campaign', levelId);
  },
  apply: (state, frames) => applyNightReplay(structuredClone(state), frames),
  result(state) {
    const result = nightReplayResult(structuredClone(state));
    return {
      ...result,
      eligible: result.cleared,
      score: result.cleared ? 1 : 0,
    };
  },
};
