import { writeFileSync, mkdirSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { readFileSync } from 'node:fs';
import { LEVELS } from './core/levels.ts';
import { createSimulation, canDispatch, dispatch, advance } from './core/simulation.ts';

const out = process.argv[2] ?? 'random';
const start = Number(process.argv[3] ?? 1);
const end = Number(process.argv[4] ?? 100);
const seeds = (process.argv[5] ?? '1,982451653,2654435761').split(',').map(Number);
const mode = process.argv[6] ?? 'random';
mkdirSync(new URL('./results/', import.meta.url), { recursive:true });
function rng(seed) { return () => ((seed = (Math.imul(seed,1664525)+1013904223)>>>0)/4294967296); }
const key = p => `${p.x},${p.z}`;
const dist = (a,b) => Math.hypot(a.x-b.x,a.z-b.z);
const assert = (ok,message,details) => {if(!ok)throw Object.assign(new Error(message),{details});};
function pointSegment(p,a,b) {
  const x=b.x-a.x,z=b.z-a.z;
  const t=Math.max(0,Math.min(1,((p.x-a.x)*x+(p.z-a.z)*z)/(x*x+z*z||1)));
  return Math.hypot(p.x-a.x-t*x,p.z-a.z-t*z);
}
function pathCheck(path,vehicle,geometry,phase) {
  assert(new Set(path.map(key)).size===path.length,'repeated route node',{vehicle:vehicle.id,phase,path});
  for(let i=1;i<path.length;i++)assert(path[i].x===path[i-1].x||path[i].z===path[i-1].z,'route diagonal',{vehicle:vehicle.id,phase,path});
  if(phase==='driving'&&vehicle.direction==='N') assert(Math.max(...path.map(p=>p.z))<=path[0].z+1e-8,'north route goes south',{vehicle:vehicle.id,path});
}
function run(level,seed) {
  const rand=rng((seed^Math.imul(level.id,104729))>>>0),s=createSimulation(level),actions=[],bindings=new Map(),pathRefs=new Map();
  let nextClick=0,minDistance=Infinity,maxConcurrentBeforeBoard=0,firstBoardTime=null,maxUnchanged=0,lastChange=0,signature='',minPair=null,maxTravel=0;
  const allPassengers=s.groups.flatMap(g=>g.passengers.map(p=>p.id));
  assert(new Set(allPassengers).size===allPassengers.length,'duplicate initial passenger');
  const trace=[];
  try {
    for(let tick=0;tick<20000&&!s.won;tick++) {
      if(s.time+1e-8>=nextClick) {
        let available=s.vehicles.filter(v=>canDispatch(s,v.id).ok);
        do {
          if(!available.length)break;
          const chosen=mode==='first'?available[0]:mode==='last'?available.at(-1):available[Math.floor(rand()*available.length)];
          const expected=s.groups.filter(g=>g.state==='ready'&&g.passengers.length<=chosen.passengerCapacity).sort((a,b)=>a.sequence-b.sequence||a.splitOrder-b.splitOrder)[0];
          const result=dispatch(s,chosen.id); assert(result.ok,'legal dispatch rejected',{chosen:chosen.id,result});
          const job=s.services.at(-1),bay=s.geometry.bays.find(b=>b.id===job.bayId);
          assert(job.groupId===expected?.id,'click assignment order mismatch',{chosen:chosen.id,expected:expected?.id,actual:job.groupId});
          assert(job.assignmentOrder===s.services.length-1,'assignment sequence mismatch');
          assert(![...bindings.values()].some(b=>b.groupId&&b.groupId===job.groupId),'duplicate service passenger group');
          assert(!bay||dist(job.pickupPoint,bay.door)<1e-8,'pickup differs from click-time door');
          bindings.set(job.vehicleId,{groupId:job.groupId,bayId:job.bayId,pickup:JSON.stringify(job.pickupPoint),walk:JSON.stringify(job.walkFrom),order:job.assignmentOrder});
          pathRefs.set(job.vehicleId,{phase:'driving',path:job.path,serialized:JSON.stringify(job.path)});
          pathCheck(job.path,chosen,s.geometry,'driving');
          actions.push({time:s.time,vehicle:chosen.id,group:job.groupId,bay:job.bayId});
          available=mode==='burst'?s.vehicles.filter(v=>canDispatch(s,v.id).ok):[];
        }while(available.length);
        nextClick=s.time+(mode==='burst'?0.05:0.05+rand()*0.95);
      }
      const before=s.vehicles.map(v=>({...v.position}));
      advance(s,0.05);
      let moved=0;
      for(let i=0;i<s.vehicles.length;i++) {
        const v=s.vehicles[i],delta=dist(v.position,before[i]);
        assert(delta<=.45000001,'teleport or overspeed',{vehicle:v.id,delta});
        if(delta>1e-8)moved++;
        if(v.state==='removed')continue;
        for(let j=i+1;j<s.vehicles.length;j++) {
          const w=s.vehicles[j];if(w.state==='removed')continue;
          const d=dist(v.position,w.position);
          if(d<minDistance){minDistance=d;minPair={time:s.time,a:v.id,b:w.id};}
          assert(d>=3.43-1e-7,'minimum center clearance violated',{time:s.time,a:v.id,b:w.id,d});
        }
      }
      if(firstBoardTime===null) {
        if(s.groups.some(g=>g.boarded>0))firstBoardTime=s.time;
        else maxConcurrentBeforeBoard=Math.max(maxConcurrentBeforeBoard,moved);
      }
      // Assert every active entire movement stays clear of every other live center.
      // Together with the atomic movement reservation, this covers between-tick motion.
      for(const [id,movement] of Object.entries(s.movements??{})) {
        for(const v of s.vehicles)if(v.id!==id&&v.state!=='removed')assert(pointSegment(v.position,movement.from,movement.to)>=3.43-1e-7,'active segment is obstructed',{id,other:v.id,movement,position:v.position});
      }
      assert(new Set(s.services.map(j=>j.vehicleId)).size===s.services.length,'duplicate vehicle service');
      for(const job of s.services) {
        const fixed=bindings.get(job.vehicleId),v=s.vehicles.find(v=>v.id===job.vehicleId),g=s.groups.find(g=>g.id===job.groupId);
        assert(fixed.groupId===job.groupId&&fixed.bayId===job.bayId&&fixed.pickup===JSON.stringify(job.pickupPoint)&&fixed.walk===JSON.stringify(job.walkFrom)&&fixed.order===job.assignmentOrder,'click-time binding changed',{job,fixed});
        assert(!g||g.vehicleId===v.id&&v.groupId===g.id,'group/vehicle inverse assignment mismatch',{job,g,v});
        const prior=pathRefs.get(job.vehicleId);
        if(job.phase==='driving')assert(prior.path===job.path&&prior.serialized===JSON.stringify(job.path),'driving route rewritten / recirculated',{job,prior});
        if(job.phase==='departing'&&prior.phase!=='departing') {
          pathCheck(job.path,v,s.geometry,'departing');pathRefs.set(v.id,{phase:'departing',path:job.path,serialized:JSON.stringify(job.path)});
        } else if(job.phase==='departing')assert(prior.path===job.path&&prior.serialized===JSON.stringify(job.path),'departure route rewritten',{job,prior});
        if(['walking','boarding','closing','exitWait'].includes(job.phase)) {
          const bay=s.geometry.bays.find(b=>b.id===job.bayId),state=s.bays.find(b=>b.id===job.bayId);
          assert(dist(v.position,bay.point)<1e-8,'passenger service away from assigned bay',{job,position:v.position,bay});
          assert(state.vehicleId===v.id&&state.groupId===g.id,'bay ownership mismatch',{job,state});
        }
        maxTravel=Math.max(maxTravel,job.travelled??0);
      }
      const delivered=s.groups.filter(g=>g.state==='departed').flatMap(g=>g.passengers.map(p=>p.id));
      assert(delivered.length===s.delivered.size&&delivered.every(id=>s.delivered.has(id)),'delivered passenger conservation mismatch');
      assert(s.groups.flatMap(g=>g.passengers).length===allPassengers.length,'passenger count changed');
      const current=JSON.stringify(s.vehicles.map(v=>[v.state,v.position.x,v.position.z]).concat(s.services.map(j=>[j.phase])));
      if(current!==signature){signature=current;lastChange=s.time;}else maxUnchanged=Math.max(maxUnchanged,s.time-lastChange);
      if(tick%20===0){trace.push({time:s.time,active:s.services.filter(j=>j.phase!=='done').map(j=>[j.vehicleId,j.phase,j.pathIndex,j.waitingForTraffic]),delivered:s.delivered.size});if(trace.length>20)trace.shift();}
      assert(s.time-lastChange<10,'permanent no-progress stall',{stalled:s.time-lastChange,legal:s.vehicles.filter(v=>canDispatch(s,v.id).ok).map(v=>v.id)});
    }
    assert(s.won,'simulation failed to terminate');
    assert(s.delivered.size===allPassengers.length,'not all passengers delivered');
    assert(s.services.length===s.vehicles.length,'vehicle dispatch count mismatch');
    return {level:level.id,seed,mode,won:true,time:s.time,minDistance,minPair,maxConcurrentBeforeBoard,firstBoardTime,maxUnchanged,maxTravel,clicks:actions.length};
  } catch(error) {
    const failure={level:level.id,seed,mode,error:error.message,details:error.details,actions,trace,state:s};
    writeFileSync(new URL(`./results/${out}-failure-L${level.id}-S${seed}.json`,import.meta.url),JSON.stringify(failure,(_k,v)=>v instanceof Set?[...v]:v,2));
    return {level:level.id,seed,mode,won:false,time:s.time,error:error.message,details:error.details,actions};
  }
}
const results=[];let failures=0;
for(const seed of seeds)for(const level of LEVELS.filter(l=>l.id>=start&&l.id<=end)) {
  const result=run(level,seed);results.push(result);
  if(!result.won){failures++;console.log(JSON.stringify(result));}
  if(results.length%10===0)console.log(JSON.stringify({progress:results.length,failures,lastLevel:level.id,seed}));
  if(failures>=3)break;
}
const summary={sourceHash:Object.fromEntries(['simulation','geometry','levels','station-traffic'].map(n=>[n,createHash('sha256').update(readFileSync(new URL(`./core/${n}.ts`,import.meta.url))).digest('hex')])),mode,cases:results.length,failures,minDistance:Math.min(...results.filter(r=>r.won).map(r=>r.minDistance)),maxTime:Math.max(...results.filter(r=>r.won).map(r=>r.time)),minConcurrentBeforeBoard:Math.min(...results.filter(r=>r.won).map(r=>r.maxConcurrentBeforeBoard)),maxConcurrentBeforeBoard:Math.max(...results.filter(r=>r.won).map(r=>r.maxConcurrentBeforeBoard))};
writeFileSync(new URL(`./results/${out}.json`,import.meta.url),JSON.stringify({summary,results},null,2));console.log(JSON.stringify(summary));
process.exitCode=failures?1:0;
